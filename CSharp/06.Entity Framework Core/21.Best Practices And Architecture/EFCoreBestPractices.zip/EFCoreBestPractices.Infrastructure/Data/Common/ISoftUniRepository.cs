﻿namespace EFCoreBestPractices.Infrastructure.Data.Common
{
    public interface ISoftUniRepository : IRepository
    {
    }
}
