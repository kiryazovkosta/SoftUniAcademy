﻿namespace PetStore.Data.Models.Common
{
    public static class ServiceValidationConstants
    {
        public const int NameMaxLength = 75;
        public const int DescriptionMaxLength = 150;
    }
}
