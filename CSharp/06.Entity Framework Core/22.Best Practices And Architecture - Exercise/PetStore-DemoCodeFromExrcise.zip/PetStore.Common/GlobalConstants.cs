﻿namespace PetStore.Common
{
    public static class GlobalConstants
    {
        public const string SystemName = "PetStore";

        public const string AdministratorRoleName = "Administrator";
    }
}
