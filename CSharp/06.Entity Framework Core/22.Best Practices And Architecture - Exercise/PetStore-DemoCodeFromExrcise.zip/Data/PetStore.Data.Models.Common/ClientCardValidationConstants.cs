﻿namespace PetStore.Data.Models.Common
{
    public static class ClientCardValidationConstants
    {
        public const int CardNumberMaxLength = 30;
    }
}
