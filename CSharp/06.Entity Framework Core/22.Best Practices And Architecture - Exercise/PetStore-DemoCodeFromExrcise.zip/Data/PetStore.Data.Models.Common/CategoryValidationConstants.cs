﻿namespace PetStore.Data.Models.Common
{
    public static class CategoryValidationConstants
    {
        public const int NameMaxLength = 50;
    }
}
