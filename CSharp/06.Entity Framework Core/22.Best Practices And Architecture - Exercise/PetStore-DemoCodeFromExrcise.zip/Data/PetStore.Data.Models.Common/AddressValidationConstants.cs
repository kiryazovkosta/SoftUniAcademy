﻿namespace PetStore.Data.Models.Common
{
    public static class AddressValidationConstants
    {
        public const int TextMaxLength = 150;
        public const int TownNameMaxLength = 75;
    }
}
