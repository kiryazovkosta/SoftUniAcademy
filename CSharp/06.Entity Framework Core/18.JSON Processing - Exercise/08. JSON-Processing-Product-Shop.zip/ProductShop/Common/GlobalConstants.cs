﻿// ReSharper disable InconsistentNaming
namespace ProductShop.Common
{
    public static class GlobalConstants
    {
        //User
        public const int UserLastNameMinLength = 3;

        //Product
        public const int ProductNameMinLength = 3;
    }
}
