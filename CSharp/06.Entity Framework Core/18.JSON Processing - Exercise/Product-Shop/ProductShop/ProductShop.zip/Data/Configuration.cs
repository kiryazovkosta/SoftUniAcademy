﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=ProductShop;Integrated Security = True";
    }
}
