﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO.Part
{
    public class ImportCarPart
    {
        public int partId { get; set; }
    }
}
