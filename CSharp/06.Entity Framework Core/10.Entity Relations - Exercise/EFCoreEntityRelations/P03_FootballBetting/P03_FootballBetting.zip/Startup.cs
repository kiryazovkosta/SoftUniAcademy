﻿using System;

namespace P03_FootballBetting
{
    internal class Startup
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
