﻿namespace Quizz.Infrastructure.Data.Common
{
    public interface IQuizzRepository : IRepository
    {
    }
}
