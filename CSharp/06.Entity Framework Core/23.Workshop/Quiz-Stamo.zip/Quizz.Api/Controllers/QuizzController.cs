﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Quizz.Core.Contracts;

namespace Quizz.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuizzController : ControllerBase
    {
        private readonly IQuizzService service;

        public QuizzController(IQuizzService _service)
        {
            service = _service;
        }

        /// <summary>
        /// Get all quizzes
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Produces("application/json")]
        public async Task<IActionResult> GetQuizzes()
        {
            var quizzes = await service.GetQuizzesAsync();

            return Ok(quizzes);
        }

    }
}
