﻿// ReSharper disable InconsistentNaming
namespace SoftUni.App
{
    public static class Config
    {
        public const string ConnectionString =
            @"Server=.;Database=MiniORM;Integrated Security=True;";
    }
}
