﻿namespace Raiding
{
    public enum BaseHeroType
    {
        Druid = 0,
        Paladin = 1,
        Rogue = 2,
        Warrior = 3
    }
}
