﻿namespace BorderControl
{
    public interface IHaveId
    {
        string Id { get; }
    }
}