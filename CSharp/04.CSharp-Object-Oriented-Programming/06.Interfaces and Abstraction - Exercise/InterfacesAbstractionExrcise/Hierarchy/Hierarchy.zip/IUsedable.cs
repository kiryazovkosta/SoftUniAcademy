﻿namespace Hierarchy
{
    public interface IUsedable
    {
        int Used { get; }
    }
}
