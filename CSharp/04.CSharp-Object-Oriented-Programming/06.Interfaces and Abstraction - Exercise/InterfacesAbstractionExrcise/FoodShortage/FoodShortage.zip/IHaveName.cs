﻿namespace FoodShortage
{
    public interface IHaveName
    {

    }
}
