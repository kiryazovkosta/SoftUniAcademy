﻿namespace Telephony
{
    public interface ICallable
    {
        string MakeCall(string number);
    }
}