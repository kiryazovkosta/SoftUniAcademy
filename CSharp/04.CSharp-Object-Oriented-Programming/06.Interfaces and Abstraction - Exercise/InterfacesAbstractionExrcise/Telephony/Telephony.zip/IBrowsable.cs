﻿namespace Telephony
{
    public interface IBrowsable
    {
        string Browsing(string url);
    }
}