﻿namespace P02._DrawingShape_After.Contracts
{
    interface IDrawingManager
    {
        void Draw(IShape shape);
    }
}
