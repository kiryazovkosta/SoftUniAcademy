﻿namespace P02._Worker_Before
{
    public class Manager
    {
        public Manager()
        {
            var worker = new Worker();
            worker.Work();
        }
    }
}
