﻿namespace P02._Books_After
{
    using System.Collections.Generic;

    public class Library
    {
        private List<Book> books;

        public Library()
        {
            this.books = new List<Book>();
        }

        public int FindBook(string title)
        {
            //Logic
            return 42;
        }
    }
}
