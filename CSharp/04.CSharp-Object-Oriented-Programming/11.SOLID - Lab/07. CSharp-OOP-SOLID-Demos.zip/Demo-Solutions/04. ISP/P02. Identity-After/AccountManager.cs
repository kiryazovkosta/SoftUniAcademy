﻿namespace P02._Identity_After
{
    using Contracts;
    public class AccountManager : IAccountManager
    {
        public void ChangePassword(string oldPass, string newPass)
        {
            // change password
        }
    }
}
