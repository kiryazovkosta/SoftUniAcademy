﻿namespace Guild
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Player
    {
        public Player(string name, string className)
        {
            Name = name;
            Class = className;
            Rank = "Trial";
            Description = "n/a";
        }

        public string Name { get; set; }
        public string Class { get; set; }
        public string Rank { get; set; }
        public string Description { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Player {this.Name}: {this.Class}");
            sb.AppendLine($"Rank: {this.Rank}");
            sb.AppendLine($"Description: {this.Description}");

            return sb.ToString().TrimEnd();
        }
    }
}
