﻿namespace CarManufacturer
{
    using System;
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();

            car.Make = "Toyota";
            car.Model = "Corolla";
            car.Year = 2014;
            car.FuelConsumption = 200;
            car.FuelQuantity = 200;
            car.Drive(2000);
            Console.WriteLine(car.WhoAmI());
        }
    }
}
