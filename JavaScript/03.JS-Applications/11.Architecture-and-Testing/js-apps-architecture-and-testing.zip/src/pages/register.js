const registerSection = document.querySelector('.register');

export function renderRegister() {
    registerSection.style.display = 'block';
}