const notFoundSection = document.querySelector('.not-found');

export function render404() {
    notFoundSection.style.display = 'block';
}