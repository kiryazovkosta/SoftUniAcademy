You need to start server into src/server/server.js.
Run from terminal or console node server.js